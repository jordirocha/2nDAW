## EXERCICI 1
Escriu el teu DNI complet (exemple 12345678Z) i el programa respon si és o no correcte. Escriu el resultat per pantalla i per consola

## EXERCICI 2 
Escriu un programa que ens deixi introduir una frase qualsevol i ens mostri si és o no palíndroma. Escriu el resultat per pantalla i per consola
## EXERCICI 3 
Programa que :
- demana 6 números per pantalla i els fica dins d’un array.
- mostrar l’array sencer en el cos de la pàgina i a la consola.
- treu el vector ordenat i el mostra en el cos de la pàgina i a la consola.
- inverteix el seu ordre i el mostra en el cos de la pàgina i a la consola.
- mostra el total d’elements de l’array.
- busca un valor introduït per l’usuari i ens diu si hi és o no a l’array i, en el cas que hi sigui, ens dóna la seva posició

## EXERCICI 4
Realitza una pàgina que faci estadístiques sobre una cadena de text que li passem: comptant el nombre de vegades que apareix cada lletra, nombre de paraules totals, primera paraula, darrera paraula, les paraules col·locades en ordre invers, les paraules ordenades de la a la z i les paraules ordenades de la z a la a. Utilitzar un Array per emmagatzemar la informació estadística.
